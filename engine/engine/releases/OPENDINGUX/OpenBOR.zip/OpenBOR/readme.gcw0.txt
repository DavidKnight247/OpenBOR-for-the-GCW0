OpenBOR [http://www.chronocrash.com] for GCW-Zero

Default directories
===================
* PAK files: /data/local/share/OpenBOR/Paks
* Save files: /data/local/home/.OpenBOR/Saves
* Logs files: /data/local/home/.OpenBOR/Logs 
